package week3.day2.assignment;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class CreateTicket extends BaseClass{
	
	@Test
	public void createJiraTicket() {
		System.out.println("Log Jira Ticket Execution Started");
		System.out.println("=================================");
		inputFile = new File("./src/main/java/week3/day2/assignment/inputjson/createJira.json");
		inputRequrest = RestAssured.given().contentType("application/Json").when().body(inputFile);
		apiResponse = inputRequrest.post("2/issue/");
		apiResponse.then().assertThat().statusCode(201);
		jKey = apiResponse.jsonPath().getString("key");
		if (apiResponse.getStatusCode() == 201) {
			System.out.println("New Jira Ticket Logged, Ticket id ="+jKey);
		}else
		{
			System.out.println("Ticket Not logged");
		}
	}

}
