package week3.day2.assignment;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class UpdateTicket extends BaseClass{

	@Test(dependsOnMethods = "week3.day2.assignment.CreateTicket.createJiraTicket")
	public void updateJiraTicket() {
		System.out.println("Update Jira Ticket Execution Started");
		System.out.println("====================================");
		inputFile = new File("./src/main/java/week3/day2/assignment/inputjson/updateJira.json");
		inputRequrest = RestAssured.given().contentType("application/Json").when().body(inputFile);
		apiResponse = inputRequrest.put("2/issue/"+jKey);
		apiResponse.then().assertThat().statusCode(204);
		System.out.println("Status Code Validated, Discription updated");
	}
}
