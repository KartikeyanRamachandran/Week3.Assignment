package week3.day2.assignment;

import java.io.File;

import org.testng.annotations.BeforeClass;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {

	public static String jKey;
	public File inputFile;
	public String apiVersion;
	
	public RequestSpecification inputRequrest;
	public Response apiResponse;

	@BeforeClass
	public void init() {

		RestAssured.baseURI = "https://kabirinfotech.atlassian.net/rest/api/";

		RestAssured.authentication = RestAssured.preemptive().basic("karthikit73@gmail.com", "ATATT3xFfGF0wBtEF22oiTvQmf5UEJO2KbVCWPP7J3DT8dpFSCEBjkgHbJgnfmvOUuC6igUv9_d99xJVc95yrhSAwVnF2plFn-6zkazLFpzZwz_QjRxsa_AT6IszqYEmzPZycd5ca878BiyjJwclewT9VtNC8TfmdgDbX4osVoHIMsUHBUEO1-s=0D3E9138");


	}
}
