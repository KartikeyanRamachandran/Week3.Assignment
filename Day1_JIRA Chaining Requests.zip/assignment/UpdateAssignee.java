package week3.day2.assignment;

import org.testng.annotations.Test;

import io.restassured.RestAssured;


public class UpdateAssignee extends BaseClass{
	
	@Test(dependsOnMethods = "week3.day2.assignment.UpdateTicket.updateJiraTicket")
	public void addTicketAssignee() {
		System.out.println("Update Jira Ticket Execution Started");
		System.out.println("====================================");
		
		inputRequrest = RestAssured.given().contentType("application/Json").when().body("{\"accountId\":\"712020:26c2e42e-1980-44ee-9b79-5ac3a48cfc43\"}");
		apiResponse = inputRequrest.put("3/issue/"+jKey+"/assignee");
		apiResponse.then().assertThat().statusCode(204);
		System.out.println("Status Code Validated, Added Assignee to Ticket");
	}

}
