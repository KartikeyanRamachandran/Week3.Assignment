package week3.day2.assignment;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class DeleteTicket extends BaseClass{
	
	@Test(dependsOnMethods = "week3.day2.assignment.AddComments.AddJiraComment")
	public void DeleteJira() {
		System.out.println("Update Jira Ticket Execution Started");
		System.out.println("====================================");

		inputRequrest = RestAssured.given().contentType("application/json");
		apiResponse = inputRequrest.delete("3/issue/"+jKey);
		apiResponse.then().assertThat().statusCode(204);
		System.out.println("Status code validated, Jira ID :: "+jKey+" is Deleted");

	}

}
