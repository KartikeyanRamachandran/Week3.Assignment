package week3.day2.assignment;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class AddComments extends BaseClass{
	
	@Test(dependsOnMethods = "week3.day2.assignment.UpdateAssignee.addTicketAssignee")
	public void AddJiraComment() {
		System.out.println("Update Jira Ticket Execution Started");
		System.out.println("====================================");

		
		File inputFile = new File("./input_json/addcomments.json");
		inputRequrest = RestAssured.given().contentType("application/json").when().body(inputFile);
		
		apiResponse = inputRequrest.post("3/issue/"+jKey+"/comment");
		apiResponse.then().assertThat().statusCode(201);
		System.out.println("Status Code Validated, Comments updated");
	}

}
